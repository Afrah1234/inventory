$(function(){
    $('#category').change(function(){
      $('#myselect').empty();

      if($("#category").val()=="All"){
      $('#myselect').append(`<option value="All" selected hidden> All </option>`);
      }
      
    
    else
  
  
  
  
  {     $('#myselect').append(`<option value="All" selected > All </option>`);
        var parameters = { search: $(this).val() };
          $.get( '/searching',parameters, function(data) {
          //$('#results').html(data[0].iname);
  
        data.forEach(item => {
  
          
  
         // document.getElementById("results").innerHTML=document.getElementById("results").innerHTML+'\n'+item.iname;
         $('#myselect').append(`<option value="${item.iname}">  ${item.iname} </option>`); 
        });
  
  
        });       }
       
    }); });



    function schin(){
    
        
          $.get( '/bringall', function(data) {
          
            
            if($("#category").val()=="All"){

                var tb = document.getElementById('names');
                while(tb.rows.length > 1) {
                tb.deleteRow(1);
              }
               
              for(i=0;i<data.length;i++){
                  $("<tr><td>" + (i+1)+ "</td><td>"+data[i].iname + "</td><td>" + data[i].cname +"</td><td>"+data[i].quantity  +"</td><td>"+data[i].UOM +"</td></tr>").appendTo("#names")
              }


            }

            else if($("#myselect").val()=="All"){

                var tb = document.getElementById('names');
                while(tb.rows.length > 1) {
                tb.deleteRow(1);
              }
               
              for(i=0;i<data.length;i++){
                  if(data[i].cname==$("#category").val())
                  $("<tr><td>" + (i+1)+ "</td><td>"+data[i].iname + "</td><td>" + data[i].cname +"</td><td>"+data[i].quantity  +"</td><td>"+data[i].UOM +"</td></tr>").appendTo("#names")
              }

            }

            else{
                var tb = document.getElementById('names');
                while(tb.rows.length > 1) {
                tb.deleteRow(1);
              }
               
              for(i=0;i<data.length;i++){
                  if(data[i].cname==$("#category").val() && data[i].iname==$("#myselect").val() )
                  $("<tr><td>" + (i+1)+ "</td><td>"+data[i].iname + "</td><td>" + data[i].cname +"</td><td>"+data[i].quantity  +"</td><td>"+data[i].UOM +"</td></tr>").appendTo("#names")
              }
            }
  
            var table = document.getElementById("names");
            for(i=0;i<table.rows.length;i++)
            { if(table.rows[i].cells[3].innerHTML==0)
            table.rows[i].style.color="rgb(255, 0, 0)";

            else if(table.rows[i].cells[3].innerHTML<=30)
            table.rows[i].style.color="	rgb(255, 191, 0)";

            else
            table.rows[i].style.color="green";
            }         
  
        });
      
      }
       
    