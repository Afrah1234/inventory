$(function(){
    $('#category').change(function(){
      $('#myselect').empty();
      $('#myselect').append(`<option value="select" selected hidden> select </option>`);
      
      
      $('#uom').val("");
      $('#rate').val("0");
      $('#quantity').val("0");
      $('#amount').val("0");
  
  
  
  
  
  
        var parameters = { search: $(this).val() };
          $.get( '/searching',parameters, function(data) {
          //$('#results').html(data[0].iname);
  
        data.forEach(item => {
  
          
  
         // document.getElementById("results").innerHTML=document.getElementById("results").innerHTML+'\n'+item.iname;
         $('#myselect').append(`<option value="${item.iname}">  ${item.iname} </option>`); 
        });
  
  
        });
       
    });
  
  
  
  
  
   $('#myselect').change(function(){
      
        var parameters = { search: $(this).val() };
          $.get( '/searchinfo',parameters, function(data) {
          
            
  
            $('#uom').val(data[0].UOM);
            $('#rate').val(data[0].SPU);
            $('#quantity').val("0");
             $('#amount').val("0");
             $("#quantity").attr({
              "max" : data[0].quantity
              
           });
  
        });
       
    });  
  
   
  
  });
  
  
  
  
  
  
  function amount(){
      
    if ($("#quantity").val() > $("#quantity").attr('max')*1) {       $("#quantity").val($("#quantity").attr('max'));     }  
          
  
    
    var amt = $('#rate').val() * $('#quantity').val();
  
     $('#amount').val(amt);
  
  
  
  }
  
  ////
  
  
  
  
  var jsonNames =[];// [{ item: "Cinthol", UOM: "Pieces", quantity:3,rate:25,amount:75 }
  //,{item:"pears",UOM:"pieces",quantity:5,rate:45,amount:100},
  //{item:"lux",UOM:"pieces",quantity:6,rate:60,amount:300}
  //];
  
  function tablefill()
  {   
       
       var item=$("#myselect").val();
      var UOM =$("#uom").val();
      var quantity =$("#quantity").val();
     var rate =$("#rate").val();  
     var amount =$("#amount").val();
     
     jsonNames.push({item:item,UOM:UOM,quantity:quantity,rate:rate,amount:amount});
   
  
  var tb = document.getElementById('names');
    while(tb.rows.length > 1) {
    tb.deleteRow(1);
  }
   
  for(i=0;i<jsonNames.length;i++){
      $("<tr><td>" + (i+1)+ "</td><td>"+jsonNames[i].item + "</td><td>" + jsonNames[i].UOM +"</td><td>"+jsonNames[i].quantity  +"</td><td>"+jsonNames[i].rate+"</td><td>"+jsonNames[i].amount+"</td></tr>").appendTo("#names")
  }
  
  
  var total=0;
  for(i=0;i<jsonNames.length;i++){
  
    total=total+parseInt(jsonNames[i].amount);
    
  }
  
  $("<tr><td colspan='6'>" +"Total = "+ (total) +"</td></tr>").appendTo("#names");
  
  clearinput();
  
  }
  
  
  
  
  
  
  
  function clearinput() ///////
  {
    document.getElementById('category').value = "select";
    $('#myselect').empty();
      $('#myselect').append(`<option value="select" selected hidden> select </option>`);
      
      
      $('#uom').val("");
      $('#rate').val("0");
      $('#quantity').val("0");
      $('#amount').val("0");
  
  
  }
  
  
  
  
  ////////
  
  function psubmit (){
  
  
  
    var total=0;
    for(i=0;i<jsonNames.length;i++){
    
      total=total+parseInt(jsonNames[i].amount);
      
    }
  
  
  
      
    var parameters = { sname:$("#sname").val(),
                      pref:$("#pref").val(),
                      sref:$("#sref").val(),
                      date:$("#date").val(),
                      total:total,
                      table2: jsonNames };
      $.get( '/postsales',parameters, function(data) {});
  
      var tb = document.getElementById('names');
      while(tb.rows.length > 1) {
      tb.deleteRow(1);
    }
  
    $("#pref").val("");
    $("#sref").val("");
    $("#sname").val("");
  
   
  }  

 

     