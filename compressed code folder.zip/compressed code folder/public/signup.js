function validate()
{ var val=true;

var uname=document.getElementById("uname");
var pass=document.getElementById("pass");
var conpass=document.getElementById("conpass");
var phone=document.getElementById("phone");
var email=document.getElementById("email");

var label1=document.getElementById("label1");
var label2=document.getElementById("label2");
var label3=document.getElementById("label3");
var label4=document.getElementById("label4");
var label5=document.getElementById("label5");

var male=document.getElementById("male");
var female=document.getElementById("female");
var other=document.getElementById("other");


var regex=/^[789][0-9]{9}$/; //phone number
var regex1=/^([a-z A-Z 0-9 \. -]+)@([a-z A-Z 0-9 -]+).([a-z ]{2,8})(.[a-z] {2,8})?$/; //email

if(uname.value.trim()=="")
{
    label1.style.visibility="visible";
    uname.style.border="solid 2px red";
    val=false;
}
if(pass.value.length<8)
{ 
    label2.style.visibility="visible";
    pass.style.border="solid 2px red";
    label3.style.visibility="visible";
    conpass.style.border="solid 2px red";
    val=false;
}

if(conpass.value!=pass.value)
{   label3.style.visibility="visible";
    conpass.style.border="solid 2px red";
    val=false;}


if(regex.test(phone.value)==false)
{label4.style.visibility="visible";
phone.style.border="solid 2px red";
val=false;}


if(regex1.test(email.value)==false)
{label5.style.visibility="visible";
email.style.border="solid 2px red";
val=false;}

if(male.checked==false && other.checked==false && female.checked==false)
{label6.style.visibility="visible";
val=false;
}
return val;

}

function fun3()
{ var x = document.getElementById("conpass");
 var label= document.getElementById("label3");
 x.style.border="none";
 x.style.borderBottom = "2px solid purple";
 label.style.visibility="hidden";
}

function fun2()
{ var x = document.getElementById("pass");
 var label= document.getElementById("label2");
 x.style.border="none";
 x.style.borderBottom = "2px solid purple";
 label.style.visibility="hidden";

}

function fun1()
{ var x = document.getElementById("uname");
 var label= document.getElementById("label1");
 x.style.border="none";
 x.style.borderBottom = "2px solid purple";
 label.style.visibility="hidden";

}

function fun4()
{ var x = document.getElementById("phone");
 var label4= document.getElementById("label4");
 x.style.border="none";
 x.style.borderBottom = "2px solid purple";
 label4.style.visibility="hidden";

}

function fun5()
{ var x = document.getElementById("email");
 var label= document.getElementById("label5");
 x.style.border="none";
 x.style.borderBottom = "2px solid purple";
 label.style.visibility="hidden";

}
function fun6()
{ var label=document.getElementById("label6");
   label.style.visibility="hidden";


}