$(function(){
    $('#category').change(function(){
      $('#myselect').empty();

      if($("#category").val()=="All"){
      $('#myselect').append(`<option value="All" selected hidden> All </option>`);
      }
      
    
    else
  
  
  
  
  {     $('#myselect').append(`<option value="All" selected > All </option>`);
        var parameters = { search: $(this).val() };
          $.get( '/searching',parameters, function(data) {
          //$('#results').html(data[0].iname);
  
        data.forEach(item => {
  
          
  
         // document.getElementById("results").innerHTML=document.getElementById("results").innerHTML+'\n'+item.iname;
         $('#myselect').append(`<option value="${item.iname}">  ${item.iname} </option>`); 
        });
  
  
        });       }
       
    }); });



    function schin(){
         
        
        if( $("#from").val()==""||$("#to").val()=="")
        alert("Enter the date");
        else
        {  $.get( '/bringpur', function(data) {
          
            
            if($("#category").val()=="All"){

                var tb = document.getElementById('names');
                while(tb.rows.length > 1) {
                tb.deleteRow(1);
              }
               
              for(i=0;i<data.length;i++){

                   if(data[i].pdate.slice(0, -14) >= $("#from").val() && data[i].pdate.slice(0, -14) <=  $("#to").val())
                   
                   
                   $("<tr><td>" +data[i].pref + "</td><td>" + data[i].pdate.slice(0, -14) +"</td><td>"+data[i].iname  +"</td><td>"+data[i].comname +"</td><td>"+data[i].quantity + "</td><td>"+data[i].rate+"</td><td>"+data[i].amount+"</td></tr>").appendTo("#names");
              }


            }

            else if($("#myselect").val()=="All"){

                var tb = document.getElementById('names');
                while(tb.rows.length > 1) {
                tb.deleteRow(1);
              }
               
              for(i=0;i<data.length;i++){
                  if(data[i].cname==$("#category").val() && (data[i].pdate.slice(0, -14) >= $("#from").val() && data[i].pdate.slice(0, -14) <=  $("#to").val()))
                  $("<tr><td>" +data[i].pref + "</td><td>" + data[i].pdate.slice(0, -14) +"</td><td>"+data[i].iname  +"</td><td>"+data[i].comname +"</td><td>"+data[i].quantity + "</td><td>"+data[i].rate+"</td><td>"+data[i].amount+"</td></tr>").appendTo("#names");
              }

            }

            else{
                var tb = document.getElementById('names');
                while(tb.rows.length > 1) {
                tb.deleteRow(1);
              }
               
              for(i=0;i<data.length;i++){
                  if(data[i].cname==$("#category").val() && data[i].iname==$("#myselect").val() && (data[i].pdate.slice(0, -14) >= $("#from").val() && data[i].pdate.slice(0, -14) <=  $("#to").val()))
                  $("<tr><td>" +data[i].pref + "</td><td>" + data[i].pdate.slice(0, -14) +"</td><td>"+data[i].iname  +"</td><td>"+data[i].comname +"</td><td>"+data[i].quantity + "</td><td>"+data[i].rate+"</td><td>"+data[i].amount+"</td></tr>").appendTo("#names");
              }
            }
  
            
  
        });

       
        
      }}