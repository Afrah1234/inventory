$(function(){
    $('#category').change(function(){
      $('#myselect').empty();

      
  
  
  
  {     
        var parameters = { search: $(this).val() };
          $.get( '/searching',parameters, function(data) {
       
  
        data.forEach(item => {
  
          
  
         
         $('#myselect').append(`<option value="${item.iname}">  ${item.iname} </option>`); 
        });
  
  
        });       }
       
    }); });



    function schin(){
    
        
          $.get( '/showirbh', function(data) {
          
            

                var tb = document.getElementById('names');
                while(tb.rows.length > 1) {
                tb.deleteRow(1);
              }
               
              for(i=0;i<data.length;i++){
                  if($('#myselect').val()==data[i].iname)
                  $("<tr><td>" + (i+1)+  "</td><td>"+data[i].pref + "</td><td>"+ data[i].pdate +"</td><td>"+data[i].iname + "</td><td>" + data[i].quantity +"</td><td>"+data[i].comname  +"</td><td>"+data[i].purchase + "</td><td>"+0+"</td></tr>").appendTo("#names")
              }


            

            
  
            var table = document.getElementById("names");
            
            
            for(i=table.rows.length-1;i>=1;i--)
            {    if(i==table.rows.length-1)
                table.rows[i].cells[7].innerHTML=table.rows[i].cells[4].innerHTML;

                else if(table.rows[i].cells[6].innerHTML=="purchase")
                table.rows[i].cells[7].innerHTML= parseInt(table.rows[i].cells[4].innerHTML) + parseInt (table.rows[i+1].cells[7].innerHTML) ;
            
                else if(table.rows[i].cells[6].innerHTML=="sales")
                table.rows[i].cells[7].innerHTML= table.rows[i+1].cells[7].innerHTML - table.rows[i].cells[4].innerHTML;
              
            }         
  
        });
      
      }
       
    