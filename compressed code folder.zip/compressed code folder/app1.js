var express=require('express');
var S = require('string');
var app=express();
app.set('view engine','ejs');
app.use('/public',express.static('public'));
app.use('/public/partials',express.static('partials'));
var bodyParser=require('body-parser');
var urlencodedParser=bodyParser.urlencoded({extended:false});

var mysql = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "password" ,       
  database:'mydb'
  //database can be selected here itself ! instead  use db query
});


app.get('/additem',function(req,res){
  
  if(!con._connectCalled ) 
  { con.connect(function(err) {
   if (err) throw err;
   console.log("Connected!");  }); 
   }

   con.query('select * from category',function(err,result){
    if (err) throw err;
    console.log(result);  

   
      res.render('additem',{data:result});





  });
    });
    
    
    
    app.get('/additem/:category',function(req,res){
      
      if(!con._connectCalled ) 
      { con.connect(function(err) {
       if (err) throw err;
       console.log("Connected!");  }); 
       }
    
       con.query('select iname from item where cname=?',[req.params.category],function(err,result1){
        if (err) throw err;
        console.log(result1);

        con.query('select * from category',function(err,result2){
          if (err) throw err;
          console.log(result2);
  
          res.render('adding',{selcat:req.params.category,items:result1,data:result2});
        });
 });   });
    


 app.get('/addnewitem',function(req,res){
  
  if(!con._connectCalled ) 
  { con.connect(function(err) {
   if (err) throw err;
   console.log("Connected!");  }); 
   }

   con.query('select * from category',function(err,result1){
    if (err) throw err;
    console.log(result1);  


    con.query('select max(icode)+1 as next from item ',function(err,result2){
      if (err) throw err;
      console.log(result2);   
      res.render('addnewitem',{category:result1,icode:result2});  });
});   });
    








app.post('/newitem',urlencodedParser,function(req,res){
  console.log(req.body);//

 
  if(!con._connectCalled ) 
  { con.connect(function(err) {
   if (err) throw err;
   console.log("Connected!");  }); 
   }
    
   console.log(req);

     var values=[[req.body.icode,req.body.iname, req.body.cname,req.body.uom,req.body.ppu,req.body.spu,req.body.des,0]];
     con.query("insert into item(icode,iname,cname,UOM,PPU,SPU,descript,quantity) values ?",[values],function (err, result) {
       if (err) throw err;
       console.log('inserted into item'); });


     

        
res.redirect('/itemmaster');
      
  

 
});




app.get('/itemmaster',function(req,res){
  
  if(!con._connectCalled ) 
  { con.connect(function(err) {
   if (err) throw err;
   console.log("Connected!");  }); 
   }

   con.query('select icode,iname,cname,UOM,SPU from item order by cname',function(err,result){
    if (err) throw err;
    console.log(result);  


      
      res.render('itemmaster',{data:result});  
});   });







app.get('/view/:icode',function(req,res){
 
  if(!con._connectCalled ) 
  { con.connect(function(err) {
   if (err) throw err;
   console.log("Connected!");  }); 
   }

   
   con.query('select * from item where icode=?',[req.params.icode],function(err,result){
    if (err) throw err;
    console.log(result);
    res.render('viewitem',{item:result[0]});
  });
});






app.get('/delete/:icode',function(req,res){

  
    con.query('delete from item where icode=?',[req.params.icode],function(err){
      if (err) throw err;
      
      res.redirect('/itemmaster');
    });
    
    
  });
  






  app.get('/edit/:icode',function(req,res){
 
    if(!con._connectCalled ) 
    { con.connect(function(err) {
     if (err) throw err;
     console.log("Connected!");  }); 
     }

     
     con.query('select * from item where icode=?',[req.params.icode],function(err,result1){
      if (err) throw err;
      console.log(result1);


      con.query('select * from category',function(err,result2){
        if (err) throw err;
        console.log(result2);
        res.render('edititem',{item:result1[0],category:result2});
      });

    });
});







app.post('/update',urlencodedParser,function(req,res){
  console.log(req.body);//

 
  if(!con._connectCalled ) 
  { con.connect(function(err) {
   if (err) throw err;
   console.log("Connected!");  }); 
   }
    
 
     
    let sql="update item set iname="    +  '"' +req.body.iname+ '"' +  ",cname=" + "'"+ req.body.cname +"'" + ",UOM="+'"' + req.body.uom +'"' + ",PPU="  +req.body.ppu  + ",SPU=" + req.body.spu +  ",descript="   +  "'" +  req.body.des + "'" + " where icode="+req.body.icode;
    
     con.query(sql,function (err, result) {
       if (err) throw err;
       console.log(sql);
       console.log('updated item'); });


     
res.redirect('/itemmaster');
      
  

 
});








app.get('/addnewcompany',function(req,res){
  
  if(!con._connectCalled ) 
  { con.connect(function(err) {
   if (err) throw err;
   console.log("Connected!");  }); 
   }

  
  


    con.query('select max(comcode)+1 as next from company ',function(err,result){
      if (err) throw err;
      console.log(result);   
      if(result[0].next==null)
      comcode=501;
      else
      comcode=result[0].next;
      res.render('addnewcompany',{comcode:comcode});  });
   });
      
  

 
   app.post('/newcompany',urlencodedParser,function(req,res){
    console.log(req.body);//
  
   
    if(!con._connectCalled ) 
    { con.connect(function(err) {
     if (err) throw err;
     console.log("Connected!");  }); 
     }
      
     console.log(req);
  
       var values=[[req.body.comcode,req.body.comname, req.body.comtype,req.body.tel,req.body.cp,req.body.mob,req.body.email,req.body.address,req.body.remarks]];
       con.query("insert into company(comcode,comname,comtype,telephone,cp,mobile,email,address,remarks) values ?",[values],function (err, result) {
         if (err) throw err;
         console.log('inserted into company'); });
          res.redirect('/company');
           });


  app.get('/company',function(req,res){
  
  if(!con._connectCalled ) 
  { con.connect(function(err) {
   if (err) throw err;
   console.log("Connected!");  }); 
   }

   con.query('select comcode,comname,comtype,telephone,cp from company',function(err,result){
    if (err) throw err;
    console.log(result);  


      
      res.render('company',{data:result});  
});   });



app.get('/viewcom/:comcode',function(req,res){
 
  if(!con._connectCalled ) 
  { con.connect(function(err) {
   if (err) throw err;
   console.log("Connected!");  }); 
   }

   
   con.query('select * from company where comcode=?',[req.params.comcode],function(err,result){
    if (err) throw err;
    console.log(result);
    res.render('viewcompany',{company:result[0]});
  });
});




app.get('/editcom/:comcode',function(req,res){
 
  if(!con._connectCalled ) 
  { con.connect(function(err) {
   if (err) throw err;
   console.log("Connected!");  }); 
   }

   
   con.query('select * from company where comcode=?',[req.params.comcode],function(err,result){
    if (err) throw err;
    console.log(result);


   
      res.render('editcompany',{company:result[0]});
    

  });
});







app.post('/editcompany',urlencodedParser,function(req,res){
  console.log(req.body);//

 
  if(!con._connectCalled ) 
  { con.connect(function(err) {
   if (err) throw err;
   console.log("Connected!");  }); 
   }
    
 
     
    let sql="update company set comname="    +  '"' +req.body.comname+ '"' +  ",comtype=" + "'"+ req.body.comtype +"'" + ",remarks="+'"' + req.body.remarks +'"' + ",telephone="  +req.body.tel  + ",mobile=" + req.body.mob +  ",address="   +  "'" +  req.body.address + "'" + ",email=" +"'"+ req.body.email +"'"+",cp="+"'"+req.body.cp +"'"+" where comcode="+req.body.comcode;
    
     con.query(sql,function (err, result) {
       if (err) throw err;
       console.log(sql);
       console.log('updated company'); });


     
res.redirect('/company');
      
  

 
});



  
  
  



  app.get('/searching', function(req, res){   //purchase js sales js
    var val = req.query.search;
    console.log(val);
    
   

if(!con._connectCalled ) 
  { con.connect(function(err) {
   if (err) throw err;
   console.log("Connected!");  }); 
   }

let sql='select * from item where cname = '+'"'+val+'"';
console.log(sql);
   con.query(sql ,function(err,result){
     
    if (err) throw err;
    console.log(result);
    res.send(result);
  });

 });
   




 app.get('/searchinfo', function(req, res){  //purchase js sales js
  var val = req.query.search;
  console.log(val);
  
 

if(!con._connectCalled ) 
{ con.connect(function(err) {
 if (err) throw err;
 console.log("Connected!");  }); 
 }

let sql='select UOM,SPU,quantity from item where iname = '+'"'+val+'"';
console.log(sql);
 con.query(sql ,function(err,result){
   
  if (err) throw err;
  console.log(result);
  res.send(result);
});

});
 






app.get('/newpurchase',function(req,res){ //make few changes to this for sales

  if(!con._connectCalled ) 
  { con.connect(function(err) {
   if (err) throw err;
   console.log("Connected!");  }); 
   }


   con.query('select comname from company where comtype="Supplier"',function(err,result1){
    if (err) throw err;
    console.log(result1);

    con.query('select * from category',function(err,result2){
      if (err) throw err;
     //
      console.log(result2);
      res.render('item',{data:result2,supp:result1});
    });
    
  });



  });
  
  ////////////////////////////////////////////
  app.get('/postpurchase', urlencodedParser,function(req, res){  //purchase js
    var pdetail = req.query.table2;
    console.log(pdetail);

   // var sname=req.query.sname;
   //console.log(sname); 
   
  
  if(!con._connectCalled ) 
  { con.connect(function(err) {
   if (err) throw err;
   console.log("Connected!");  }); 
   }
  //////////////////////////////////////
  //finding supid

  con.query('select comcode from company where comname='+'"'+req.query.sname+'"',function(err,supid){
    if (err) throw err;
  
   //posting in purchase master

 var values=[[req.query.pref,req.query.sref, supid[0].comcode,req.query.total,req.query.date]];
 con.query("insert into purchase_master values ?",[values],function (err, result) {
   if (err) throw err;
   });

    
  });
  ///////////////////////////////
 
  if(pdetail.length!=0){
    pdetail.forEach(function(detail){  
        //finding icode
 con.query('select icode from item where iname='+'"'+detail.item+'"',function(err,icode){
  if (err) throw err;

 //posting in purchase detail

var values=[[req.query.pref,icode[0].icode,detail.quantity,detail.rate,detail.amount]];
con.query("insert into purchase_detail values ?",[values],function (err, result) {
 if (err) throw err;
//////////
con.query("update item set quantity=quantity +" +detail.quantity+" where icode="+icode[0].icode,function (err, result) {
  if (err) throw err;
 
 
 
  });

 /////////

 });  }); }); }

 });
  //////////////////////////////////////sales/////////////

  app.get('/newsales',function(req,res){ // for sales

    if(!con._connectCalled ) 
    { con.connect(function(err) {
     if (err) throw err;
     console.log("Connected!");  }); 
     }
  
  
     con.query('select comname from company where comtype="Customer"',function(err,result1){
      if (err) throw err;
      console.log(result1);
  
      con.query('select * from category',function(err,result2){
        if (err) throw err;
       //
        console.log(result2);
        res.render('newsales',{data:result2,supp:result1});
      });
      
    });
  
  
  
    });

    /////////////
    
    app.get('/postsales', urlencodedParser,function(req, res){  //sale js
      var pdetail = req.query.table2;
      console.log(pdetail);
  
     // var sname=req.query.sname;
     //console.log(sname); 
     
    
    if(!con._connectCalled ) 
    { con.connect(function(err) {
     if (err) throw err;
     console.log("Connected!");  }); 
     }
    //////////////////////////////////////
    //finding supid
  
    con.query('select comcode from company where comname='+'"'+req.query.sname+'"',function(err,supid){
      if (err) throw err;
    
     //posting in sales master
  
   var values=[[req.query.pref,req.query.sref, supid[0].comcode,req.query.total,req.query.date]];
   con.query("insert into sales_master values ?",[values],function (err, result) {
     if (err) throw err;
     });
  
      
    });
    ///////////////////////////////
   
    if(pdetail.length!=0){
      pdetail.forEach(function(detail){  
          //finding icode
   con.query('select icode from item where iname='+'"'+detail.item+'"',function(err,icode){
    if (err) throw err;
  
   //posting in sales detail
  
  var values=[[req.query.pref,icode[0].icode,detail.quantity,detail.rate,detail.amount]];
  con.query("insert into sales_detail values ?",[values],function (err, result) {
   if (err) throw err;
 
  con.query("update item set quantity=quantity -" +detail.quantity+" where icode="+icode[0].icode,function (err, result) {
    if (err) throw err;
   
   
   
    });
  
   
  
   });  }); }); }
  
   });



////////////////////////////////////////
  app.get('/inreport',function(req,res){ //inventory report

    if(!con._connectCalled ) 
    { con.connect(function(err) {
     if (err) throw err;
     console.log("Connected!");  }); 
     }
  
  
     
  
      con.query('select * from category',function(err,result2){
        if (err) throw err;
       //
        console.log(result2);
        res.render('inreport',{data:result2});
      });
      });



      
 app.get('/bringall', function(req, res){     //inventory report
 
  
 

if(!con._connectCalled ) 
{ con.connect(function(err) {
 if (err) throw err;
 console.log("Connected!");  }); 
 }

let sql='select iname,cname,UOM,quantity from item ';
console.log(sql);
 con.query(sql ,function(err,result){
   
  if (err) throw err;
  console.log(result);
  res.send(result);
});

});
 
//////////////////////////////////////////purchase history///////////////

app.get('/purchasehistory',function(req,res){ //purchase history

  if(!con._connectCalled ) 
  { con.connect(function(err) {
   if (err) throw err;
   console.log("Connected!");  }); 
   }


   

    con.query('select * from category',function(err,result2){
      if (err) throw err;
     //
      console.log(result2);
      res.render('purchasehistory',{data:result2});
    });
    });



//////////////////////////

app.get('/bringpur', function(req, res){     //purchase history
 
  
 

  if(!con._connectCalled ) 
  { con.connect(function(err) {
   if (err) throw err;
   console.log("Connected!");  }); 
   }
  
  let sql='select  cname,purchase_master.pref,pdate,iname,comname,purchase_detail.quantity,purchase_detail.rate,purchase_detail.amount from purchase_master , purchase_detail , company, item where purchase_master.pref = purchase_detail.pref and purchase_master.supid = company.comcode and purchase_detail.icode=item.icode   order by pdate desc ';
  console.log(sql);
   con.query(sql ,function(err,result){
     
    if (err) throw err;
    console.log(result);
    res.send(result);
  });
  
  });

/////////////////////////////////////////

app.get('/saleshistory',function(req,res){ //sales history

  if(!con._connectCalled ) 
  { con.connect(function(err) {
   if (err) throw err;
   console.log("Connected!");  }); 
   }


   

    con.query('select * from category',function(err,result2){
      if (err) throw err;
     //
      console.log(result2);
      res.render('saleshistory',{data:result2});
    });
    });

//////////////
app.get('/bringsal', function(req, res){     //sales history
 
  
 

  if(!con._connectCalled ) 
  { con.connect(function(err) {
   if (err) throw err;
   console.log("Connected!");  }); 
   }
  
  let sql=' select cname,sales_master.salesref,sdate,iname,comname,sales_detail.quantity,sales_detail.rate,sales_detail.amount from sales_master,sales_detail,company,item where sales_master.salesref=sales_detail.salesref and sales_master.cusid=company.comcode and sales_detail.icode=item.icode   order by sdate desc ';
  console.log(sql);
   con.query(sql ,function(err,result){
     
    if (err) throw err;
    console.log(result);
    res.send(result);
  });
  
  });

//////////////////////////////////////////////////////

app.get('/category', function(req, res){ 
res.render('category');
});

app.post('/newcategory',urlencodedParser,function(req,res){
  console.log(req.body);//

 
  if(!con._connectCalled ) 
  { con.connect(function(err) {
   if (err) throw err;
   console.log("Connected!");  }); 
   }
    
   console.log(req);

     var values=[[req.body.iname]];
     con.query("insert into category (cname) values ?",[values],function (err, result) {
       if (err) throw err;
       console.log('inserted into category'); });

res.redirect('/category');
      });

///////////////////////////// show purchase//////////////////////////////////
app.get('/showpurchase',function(req,res){
  
  if(!con._connectCalled ) 
  { con.connect(function(err) {
   if (err) throw err;
   console.log("Connected!");  }); 
   }

   let sql='select pref,pdate ,sref,comname,amount from purchase_master,company where purchase_master.supid=company.comcode order by pdate desc ';
   
   con.query(sql,function(err,result){
    if (err) throw err;
    console.log(result); 
    for(i=0;i<result.length;i++)
    { string=S(result[i].pdate);
      result[i].pdate=string.substr(0, string.length-41);} 
    console.log(result);

      
      res.render('showpurchase',{data:result});  
});   });


//////////////////////////////view purchase//////////////////////
app.get('/purchaseview/:pref',function(req,res){
 
  if(!con._connectCalled ) 
  { con.connect(function(err) {
   if (err) throw err;
   console.log("Connected!");  }); 
   }

   
   con.query('select iname,purchase_detail.quantity,rate,amount from purchase_detail, item where item.icode = purchase_detail.icode and pref = ?',[req.params.pref],function(err,result){
    if (err) throw err;
    console.log(result);
    res.render('viewpurchase',{data:result});
  });
});

/////////////////////////////sales view//////////
app.get('/showsales',function(req,res){
  
  if(!con._connectCalled ) 
  { con.connect(function(err) {
   if (err) throw err;
   console.log("Connected!");  }); 
   }

   let sql='select salesref,sdate ,cref,comname,amount from sales_master,company where sales_master.cusid=company.comcode order by sdate desc ';
   
   con.query(sql,function(err,result){
    if (err) throw err;
    console.log(result); 
    for(i=0;i<result.length;i++)
    { string=S(result[i].sdate);
      result[i].sdate=string.substr(0, string.length-41);} 
    console.log(result);

      
      res.render('showsales',{data:result});  
});   });
////////////////////////////
app.get('/salesview/:salesref',function(req,res){
 
  if(!con._connectCalled ) 
  { con.connect(function(err) {
   if (err) throw err;
   console.log("Connected!");  }); 
   }

   
   con.query('select iname,sales_detail.quantity,rate,amount from sales_detail, item where item.icode = sales_detail.icode and salesref = ?',[req.params.salesref],function(err,result){
    if (err) throw err;
    console.log(result);
    res.render('viewsales',{data:result});
  });
});
//////////////////////////////

app.get('/',function(req,res){
  
  

      
      res.render('login');  
});   
////////////////////////////////item running balance history////////////////////////////

app.get('/irbh',function(req,res){ 

  if(!con._connectCalled ) 
  { con.connect(function(err) {
   if (err) throw err;
   console.log("Connected!");  }); 
   }


   

    con.query('select * from category',function(err,result2){
      if (err) throw err;
     //
      console.log(result2);
      res.render('irbh',{data:result2});
    });
    });



    
app.get('/showirbh', function(req, res){     //send data




if(!con._connectCalled ) 
{ con.connect(function(err) {
if (err) throw err;
console.log("Connected!");  }); 
}

let sql='(select purchase_master.pref, iname,comname ,pdate,"purchase",purchase_detail.quantity from purchase_master,purchase_detail,item,company where item.icode=purchase_detail.icode and purchase_master.pref=purchase_detail.pref and purchase_master.supid=company.comcode union all select sales_master.salesref, iname,comname ,sdate,"sales",sales_detail.quantity from sales_master,sales_detail,item,company where item.icode=sales_detail.icode and sales_master.salesref=sales_detail.salesref and sales_master.cusid=company.comcode)  order by pdate desc ; ';
console.log(sql);
con.query(sql ,function(err,result){
 
if (err) throw err;
console.log(result);
for(i=0;i<result.length;i++)
    { string=S(result[i].pdate);
      result[i].pdate=string.substr(0, string.length-41).s;} 
      console.log(result);
res.send(result);
});

});
///////////////////////////////////
app.get('/home',function(req,res){ 
      res.render('home');
    
    });
//////////////////////////////////
    app.listen(3000);